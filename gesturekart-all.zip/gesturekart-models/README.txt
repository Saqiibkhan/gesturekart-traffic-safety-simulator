Models:
- ferrari-optimized.glb: Ferrari 458 Italia from the three.js examples (interior removed, simplified).
- CesiumMilkTruck.glb: Cesium Milk Truck from the Khronos glTF sample models.
Check each model's licence before using it in a submission or publishing it.
